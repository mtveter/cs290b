package test;


public class test {
	public static void main(String[] args) {
		final double[][] cities3 =
			{
				{ 1, 1 },
				{ 8, 1 },
				{ 8, 8 },
				{ 1, 8 },
				{ 2, 2 },
				{ 7, 2 },
				{ 7, 7 },
				{ 2, 7 },
				{ 3, 3 },
				{ 6, 3 },
				{ 6, 6 },
				{ 3, 6 }
			};
		EuclideanTSP tsp = new EuclideanTSP(cities3);
		System.out.println(tsp.execute());
	}
}
